package com.originalassistant.jarvis.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/** A single free-form note the user asked Jarvis to save (requirement #5, CREATE_NOTE/READ_NOTE). */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val content: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)

/**
 * A locally-stored user preference/fact (requirement #9 — memory).
 * Only ever populated by an explicit "remember that..." command —
 * never written automatically, and never used to store sensitive data.
 */
@Entity(tableName = "memory")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fact: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)

/** A one-shot or recurring reminder scheduled via AlarmManager (requirement #8). */
@Entity(tableName = "reminders")
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val message: String,
    val triggerAtMillis: Long,
    val isRecurringDaily: Boolean = false
)
