package com.originalassistant.jarvis.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.originalassistant.jarvis.assistant.AssistantState
import com.originalassistant.jarvis.ui.theme.JarvisAccent
import com.originalassistant.jarvis.ui.theme.JarvisAccentSoft
import com.originalassistant.jarvis.ui.theme.JarvisError
import com.originalassistant.jarvis.ui.theme.JarvisWarning
import kotlin.math.sin

/**
 * The central AI core — an original ring/glow design (not a copy of any
 * existing film UI), whose color, pulse speed and ring behavior change
 * with [AssistantState] so the user always has a clear visual read on
 * whether Jarvis is idle, listening, thinking, speaking, or erroring.
 */
@Composable
fun AssistantOrb(
    state: AssistantState,
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 220.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")

    val pulseDurationMs = when (state) {
        AssistantState.IDLE -> 3000
        AssistantState.LISTENING -> 900
        AssistantState.THINKING -> 650
        AssistantState.SPEAKING -> 500
        AssistantState.ERROR -> 1200
    }

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(pulseDurationMs, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val coreColor = when (state) {
        AssistantState.ERROR -> JarvisError
        AssistantState.LISTENING -> JarvisAccent
        AssistantState.THINKING -> JarvisWarning
        AssistantState.SPEAKING -> JarvisAccent
        AssistantState.IDLE -> JarvisAccentSoft
    }

    Canvas(modifier = modifier.size(size)) {
        val center = Offset(this.size.width / 2f, this.size.height / 2f)
        val baseRadius = this.size.minDimension / 2f * 0.55f

        // Breathing pulse magnitude differs by state: a calm slow breathe
        // when idle, a tighter energetic pulse when listening/thinking.
        val pulseAmplitude = when (state) {
            AssistantState.IDLE -> 0.06f
            AssistantState.LISTENING -> 0.12f
            AssistantState.THINKING -> 0.10f
            AssistantState.SPEAKING -> 0.16f
            AssistantState.ERROR -> 0.05f
        }
        val pulse = 1f + pulseAmplitude * sin(phase * 2 * Math.PI).toFloat()
        val radius = baseRadius * pulse

        // Outer glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(coreColor.copy(alpha = 0.35f), Color.Transparent),
                center = center,
                radius = radius * 2.1f
            ),
            radius = radius * 2.1f,
            center = center
        )

        // Rotating orbit ring
        rotate(degrees = ringRotation, pivot = center) {
            drawCircle(
                color = coreColor.copy(alpha = 0.55f),
                radius = radius * 1.35f,
                center = center,
                style = Stroke(width = 3.dp.toPx())
            )
        }

        // Solid core
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(coreColor, coreColor.copy(alpha = 0.65f)),
                center = center,
                radius = radius
            ),
            radius = radius,
            center = center
        )

        // Inner ring detail
        drawCircle(
            color = Color.Black.copy(alpha = 0.25f),
            radius = radius * 0.62f,
            center = center,
            style = Stroke(width = 2.dp.toPx())
        )
    }
}
