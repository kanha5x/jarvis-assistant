package com.originalassistant.jarvis.command

import java.util.Locale

/**
 * Rule-based command parser.
 *
 * This purposefully does NOT depend on [com.originalassistant.jarvis.ai.AIService] —
 * it is a fast, deterministic, fully-offline first pass that recognizes the
 * fixed vocabulary of supported commands in Hindi, Hinglish, and English.
 * Anything it doesn't recognize falls through to [CommandAction.GENERAL_AI_CHAT],
 * which [com.originalassistant.jarvis.assistant.AssistantViewModel] then hands
 * to the AI layer for a free-form conversational reply or (in a future phase)
 * a smarter model-based classification.
 *
 * Keeping this separate from the AI layer is what makes "open WhatsApp" and
 * "what's the battery" work instantly and offline, per requirement #14.
 */
object CommandParser {

    private val appKeywords = listOf(
        "whatsapp", "instagram", "youtube", "chrome", "gmail", "camera",
        "gallery", "photos", "maps", "facebook", "spotify", "calendar",
        "settings", "calculator", "phone", "dialer", "play store", "playstore"
    )

    fun parse(rawText: String): ParsedCommand {
        val text = rawText.trim()
        val lower = text.lowercase(Locale.getDefault())

        return matchRememberFact(lower, text)
            ?: matchForgetFact(lower, text)
            ?: matchListMemory(lower, text)
            ?: matchCreateReminder(lower, text)
            ?: matchSetAlarm(lower, text)
            ?: matchSetTimer(lower, text)
            ?: matchOpenApp(lower, text)
            ?: matchYoutubeSearch(lower, text)
            ?: matchWebSearch(lower, text)
            ?: matchBattery(lower, text)
            ?: matchTime(lower, text)
            ?: matchDate(lower, text)
            ?: matchCalculator(lower, text)
            ?: matchCreateNote(lower, text)
            ?: matchReadNote(lower, text)
            ?: matchSendMessage(lower, text)
            ?: matchMakeCall(lower, text)
            ?: matchOpenSettings(lower, text)
            ?: ParsedCommand(CommandAction.GENERAL_AI_CHAT, rawText = text)
    }

    // ---- Apps -------------------------------------------------------

    private fun matchOpenApp(lower: String, raw: String): ParsedCommand? {
        val opensWith = listOf("kholo", "khol do", "khol", "open", "launch", "start")
        if (opensWith.none { lower.contains(it) }) return null

        val app = appKeywords.firstOrNull { lower.contains(it) } ?: return null
        return ParsedCommand(CommandAction.OPEN_APP, mapOf("appName" to app), raw)
    }

    private fun matchOpenSettings(lower: String, raw: String): ParsedCommand? {
        if (!lower.contains("settings")) return null
        if (!(lower.contains("kholo") || lower.contains("open") || lower.contains("khol"))) return null
        return ParsedCommand(CommandAction.OPEN_SETTINGS, rawText = raw)
    }

    // ---- Search -------------------------------------------------------

    private fun matchYoutubeSearch(lower: String, raw: String): ParsedCommand? {
        if (!lower.contains("youtube")) return null
        val triggers = listOf("search", "khojo", "dhoondo", "dikhao", "pe")
        if (triggers.none { lower.contains(it) } && !lower.contains("youtube par")) return null

        val query = extractAfterAny(lower, listOf("youtube pe", "youtube par", "on youtube", "youtube search", "youtube"))
            ?: return null
        val cleaned = query.removePrefix("search").removePrefix("for").trim()
        if (cleaned.isBlank()) return null
        return ParsedCommand(CommandAction.SEARCH_YOUTUBE, mapOf("query" to cleaned), raw)
    }

    private fun matchWebSearch(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("search for", "search", "google", "khojo", "dhoondo", "batao ki")
        val trigger = triggers.firstOrNull { lower.contains(it) } ?: return null
        if (lower.contains("youtube")) return null // handled above

        val query = extractAfterAny(lower, listOf(trigger)) ?: return null
        val cleaned = query.removePrefix("for").trim()
        if (cleaned.isBlank()) return null
        return ParsedCommand(CommandAction.SEARCH_WEB, mapOf("query" to cleaned), raw)
    }

    // ---- Device info ----------------------------------------------------

    private fun matchBattery(lower: String, raw: String): ParsedCommand? {
        val phrases = listOf("battery kitni", "battery status", "how much battery", "battery percentage", "charge kitna")
        if (phrases.none { lower.contains(it) } && !(lower.contains("battery"))) return null
        return ParsedCommand(CommandAction.GET_BATTERY, rawText = raw)
    }

    private fun matchTime(lower: String, raw: String): ParsedCommand? {
        val phrases = listOf("time kya", "what time", "samay kya", "abhi kitne baje")
        if (phrases.none { lower.contains(it) }) return null
        return ParsedCommand(CommandAction.GET_TIME, rawText = raw)
    }

    private fun matchDate(lower: String, raw: String): ParsedCommand? {
        val phrases = listOf("date kya", "aaj ki tareekh", "what's the date", "what is the date", "aaj kya date")
        if (phrases.none { lower.contains(it) }) return null
        return ParsedCommand(CommandAction.GET_DATE, rawText = raw)
    }

    // ---- Calculator -------------------------------------------------------

    private val mathExpressionRegex = Regex("""[-+]?\d+(\.\d+)?\s*[+\-x*/]\s*[-+]?\d+(\.\d+)?(\s*[+\-x*/]\s*[-+]?\d+(\.\d+)?)*""")

    private fun matchCalculator(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("calculate", "calculator", "kitna hota hai", "kitna hoga", "plus", "minus", "multiply", "divide")
        val expressionInWords = lower
            .replace("plus", "+")
            .replace("minus", "-")
            .replace("multiplied by", "x")
            .replace("multiply", "x")
            .replace("times", "x")
            .replace("divided by", "/")
            .replace("divide", "/")

        val match = mathExpressionRegex.find(expressionInWords) ?: run {
            if (triggers.none { lower.contains(it) }) return null
            return null
        }
        return ParsedCommand(CommandAction.CALCULATOR, mapOf("expression" to match.value), raw)
    }

    // ---- Timers & alarms -------------------------------------------------------

    private val durationRegex = Regex("""(\d+)\s*(minute|minutes|min|second|seconds|sec|hour|hours|ghante|ghanta|minute ka|second ka)""")

    private fun matchSetTimer(lower: String, raw: String): ParsedCommand? {
        if (!lower.contains("timer")) return null
        val match = durationRegex.find(lower) ?: return null
        val amount = match.groupValues[1]
        val unitRaw = match.groupValues[2]
        val unit = normalizeDurationUnit(unitRaw)
        return ParsedCommand(CommandAction.SET_TIMER, mapOf("amount" to amount, "unit" to unit), raw)
    }

    private val clockTimeRegex = Regex("""(\d{1,2})(:(\d{2}))?\s*(am|pm|baje)?""")

    private fun matchSetAlarm(lower: String, raw: String): ParsedCommand? {
        if (!lower.contains("alarm")) return null
        val match = clockTimeRegex.find(lower) ?: return null
        val hour = match.groupValues[1]
        val minute = match.groupValues[3].ifBlank { "0" }
        val meridiem = match.groupValues[4]
        return ParsedCommand(
            CommandAction.SET_ALARM,
            mapOf("hour" to hour, "minute" to minute, "meridiem" to meridiem),
            raw
        )
    }

    private fun matchCreateReminder(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("yaad dilana", "yaad dila", "remind me", "reminder laga", "mujhe yaad")
        if (triggers.none { lower.contains(it) }) return null

        val timeMatch = clockTimeRegex.find(lower)
        val durationMatch = durationRegex.find(lower)

        // Whatever comes after "ki" / "that" / "to" is treated as the reminder message.
        val message = extractAfterAny(lower, listOf(" ki ", " that ", " to "))?.trim()
            ?: raw

        val params = mutableMapOf("message" to message)
        if (durationMatch != null) {
            params["amount"] = durationMatch.groupValues[1]
            params["unit"] = normalizeDurationUnit(durationMatch.groupValues[2])
        } else if (timeMatch != null && timeMatch.value.isNotBlank()) {
            params["hour"] = timeMatch.groupValues[1]
            params["minute"] = timeMatch.groupValues[3].ifBlank { "0" }
            params["meridiem"] = timeMatch.groupValues[4]
        }
        return ParsedCommand(CommandAction.CREATE_REMINDER, params, raw)
    }

    private fun normalizeDurationUnit(unitRaw: String): String = when {
        unitRaw.startsWith("sec") -> "second"
        unitRaw.startsWith("hour") || unitRaw.startsWith("ghant") -> "hour"
        else -> "minute"
    }

    // ---- Notes -------------------------------------------------------

    private fun matchCreateNote(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("note bana", "likh lo", "create a note", "note likho", "make a note", "note:")
        val trigger = triggers.firstOrNull { lower.contains(it) } ?: return null
        val content = extractAfterAny(lower, listOf(trigger))?.trim().takeUnless { it.isNullOrBlank() } ?: return null
        return ParsedCommand(CommandAction.CREATE_NOTE, mapOf("content" to content), raw)
    }

    private fun matchReadNote(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("note padho", "read my note", "read note", "meri notes", "mere notes")
        if (triggers.none { lower.contains(it) }) return null
        return ParsedCommand(CommandAction.READ_NOTE, rawText = raw)
    }

    // ---- Messages & calls (always require confirmation, see requiresConfirmation) ----

    private fun matchSendMessage(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("message bhejo", "send a message", "send message", "text karo")
        if (triggers.none { lower.contains(it) }) return null

        // Pattern: "<contact> ko message bhejo: <body>" or "send message to <contact>: <body>"
        val contactMatch = Regex("""(.+?)\s*(ko|to)\s""").find(lower)
        val contact = contactMatch?.groupValues?.get(1)?.trim()
        val body = raw.substringAfter(":").trim().takeUnless { it.isBlank() }
            ?: extractAfterAny(lower, triggers)?.trim()

        val params = mutableMapOf<String, String>()
        if (!contact.isNullOrBlank()) params["contact"] = contact
        if (!body.isNullOrBlank()) params["body"] = body
        return ParsedCommand(CommandAction.SEND_MESSAGE, params, raw)
    }

    private fun matchMakeCall(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("call karo", "call kar do", "make a call", "phone karo", "dial karo")
        val trigger = triggers.firstOrNull { lower.contains(it) } ?: return null
        val contact = lower.substringBefore(trigger).trim().takeUnless { it.isBlank() }
        val params = if (!contact.isNullOrBlank()) mapOf("contact" to contact) else emptyMap()
        return ParsedCommand(CommandAction.MAKE_CALL, params, raw)
    }

    // ---- Memory (requirement #9) -------------------------------------------------------

    private fun matchRememberFact(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("remember that", "remember this", "yaad rakho ki", "yaad rakhna")
        val trigger = triggers.firstOrNull { lower.contains(it) } ?: return null
        val fact = extractAfterAny(lower, listOf(trigger))?.trim().takeUnless { it.isNullOrBlank() } ?: return null
        return ParsedCommand(CommandAction.REMEMBER_FACT, mapOf("fact" to fact), raw)
    }

    private fun matchForgetFact(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("forget what i told you about", "forget about", "bhool jao")
        val trigger = triggers.firstOrNull { lower.contains(it) } ?: return null
        val topic = extractAfterAny(lower, listOf(trigger))?.trim().takeUnless { it.isNullOrBlank() } ?: return null
        return ParsedCommand(CommandAction.FORGET_FACT, mapOf("topic" to topic), raw)
    }

    private fun matchListMemory(lower: String, raw: String): ParsedCommand? {
        val triggers = listOf("what do you remember about me", "what do you remember", "mujhe kya yaad hai")
        if (triggers.none { lower.contains(it) }) return null
        return ParsedCommand(CommandAction.LIST_MEMORY, rawText = raw)
    }

    // ---- Helpers -------------------------------------------------------

    private fun extractAfterAny(text: String, needles: List<String>): String? {
        for (needle in needles) {
            val idx = text.indexOf(needle)
            if (idx >= 0) {
                return text.substring(idx + needle.length)
            }
        }
        return null
    }
}
