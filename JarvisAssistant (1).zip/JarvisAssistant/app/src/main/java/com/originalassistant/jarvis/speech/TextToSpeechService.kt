package com.originalassistant.jarvis.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/**
 * Thin wrapper around Android's built-in [TextToSpeech] engine.
 *
 * Uses the platform TTS engine (Google's or whichever is set as default)
 * rather than a cloud voice API, so speech output works fully offline
 * per requirement #14, and needs no API key.
 */
class TextToSpeechService(context: Context) {

    private var tts: TextToSpeech? = null
    private var isReady = false
    private var pendingSpeak: (() -> Unit)? = null

    var speechRate: Float = 1.0f
        set(value) {
            field = value
            tts?.setSpeechRate(value)
        }

    var language: Locale = Locale("hi", "IN")
        set(value) {
            field = value
            tts?.language = value
        }

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            isReady = status == TextToSpeech.SUCCESS
            if (isReady) {
                tts?.language = language
                tts?.setSpeechRate(speechRate)
                pendingSpeak?.invoke()
                pendingSpeak = null
            }
        }
    }

    fun speak(
        text: String,
        onStart: () -> Unit = {},
        onDone: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        val engine = tts
        if (!isReady || engine == null) {
            // Queue until initialization finishes (covers the first
            // launch race where speak() is called before onInit fires).
            pendingSpeak = { speak(text, onStart, onDone, onError) }
            return
        }

        val utteranceId = UUID.randomUUID().toString()
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = onStart()
            override fun onDone(utteranceId: String?) = onDone()

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                onError("Text-to-speech mein error aaya.")
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                onError("Text-to-speech mein error aaya (code $errorCode).")
            }
        })

        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }
}
