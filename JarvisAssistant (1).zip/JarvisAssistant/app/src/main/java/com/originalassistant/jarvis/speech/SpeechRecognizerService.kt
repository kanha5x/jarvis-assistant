package com.originalassistant.jarvis.speech

import android.content.Context
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * Thin, testable wrapper around Android's on-device/system [SpeechRecognizer].
 *
 * Uses `Locale("hi", "IN")` by default because Android's speech recognizer,
 * when given the Hindi-India locale, transcribes mixed Hindi-English
 * (Hinglish) speech reasonably well in Latin/Devanagari mixed form on most
 * devices with Google's speech services installed. Users can change this
 * in Settings (English / Hindi) per requirement #11.
 *
 * IMPORTANT (per Android policy): this only listens while explicitly
 * started (mic button tap, or a foreground "listening" session after wake
 * word detection in Phase 6). It does NOT record continuously in the
 * background — that is not something Android allows for a normal app.
 */
class SpeechRecognizerService(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(
        languageTag: String = "hi-IN",
        onPartialResult: (String) -> Unit,
        onFinalResult: (String) -> Unit,
        onError: (String) -> Unit,
        onReadyForSpeech: () -> Unit = {},
        onEndOfSpeech: () -> Unit = {}
    ) {
        stopListening() // ensure no stale instance is running

        if (!isAvailable()) {
            onError("Speech recognition is not available on this device.")
            return
        }

        val speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = speechRecognizer

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale(languageTag).toString().ifBlank { languageTag })
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) {
                onReadyForSpeech()
            }

            override fun onBeginningOfSpeech() = Unit

            override fun onRmsChanged(rmsdB: Float) = Unit

            override fun onBufferReceived(buffer: ByteArray?) = Unit

            override fun onEndOfSpeech() {
                onEndOfSpeech()
            }

            override fun onError(error: Int) {
                onError(describeError(error))
            }

            override fun onResults(results: android.os.Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) {
                    onFinalResult(text)
                } else {
                    onError("Kuch samajh nahi aaya. Dobara try karein.")
                }
            }

            override fun onPartialResults(partialResults: android.os.Bundle?) {
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) onPartialResult(text)
            }

            override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
        })

        speechRecognizer.startListening(intent)
    }

    fun stopListening() {
        recognizer?.let {
            it.stopListening()
            it.cancel()
            it.destroy()
        }
        recognizer = null
    }

    private fun describeError(errorCode: Int): String = when (errorCode) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording mein error aaya."
        SpeechRecognizer.ERROR_CLIENT -> "Kuch technical error aaya."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission nahi hai."
        SpeechRecognizer.ERROR_NETWORK -> "Network error. Internet check karein."
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout ho gaya."
        SpeechRecognizer.ERROR_NO_MATCH -> "Kuch samajh nahi aaya. Dobara bolen."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer abhi busy hai."
        SpeechRecognizer.ERROR_SERVER -> "Server error aaya."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch sunayi nahi diya."
        else -> "Ek anjaan error aaya (code $errorCode)."
    }
}
