package com.originalassistant.jarvis.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.originalassistant.jarvis.assistant.AssistantState
import com.originalassistant.jarvis.assistant.AssistantUiState
import com.originalassistant.jarvis.ui.components.AssistantOrb
import com.originalassistant.jarvis.ui.components.ChatBubble
import com.originalassistant.jarvis.ui.theme.JarvisAccent
import com.originalassistant.jarvis.ui.theme.JarvisBackground
import com.originalassistant.jarvis.ui.theme.JarvisError
import com.originalassistant.jarvis.ui.theme.JarvisTextSecondary

@Composable
fun MainScreen(
    uiState: AssistantUiState,
    onMicTapped: () -> Unit,
    onInputTextChanged: (String) -> Unit,
    onSendTypedMessage: () -> Unit,
    onOpenSettings: () -> Unit,
    onDismissError: () -> Unit,
    onConfirmPendingAction: () -> Unit,
    onCancelPendingAction: () -> Unit
) {
    uiState.pendingAction?.let { pending ->
        com.originalassistant.jarvis.ui.components.ConfirmationDialog(
            pendingAction = pending,
            onConfirm = onConfirmPendingAction,
            onCancel = onCancelPendingAction
        )
    }

    Scaffold(
        containerColor = JarvisBackground,
        topBar = { TopStatusBar(uiState.isOnline, onOpenSettings) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            ConversationList(
                messages = uiState.messages,
                modifier = Modifier.weight(1f)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                AssistantOrb(state = uiState.state)
            }

            StateLabel(uiState)

            if (uiState.partialTranscript.isNotBlank()) {
                Text(
                    text = uiState.partialTranscript,
                    color = JarvisTextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            uiState.errorMessage?.let { error ->
                LaunchedEffect(error) {
                    // Auto-dismiss the inline error banner after a few
                    // seconds so it doesn't sit on screen forever.
                    kotlinx.coroutines.delay(3500)
                    onDismissError()
                }
                Text(
                    text = error,
                    color = JarvisError,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

            InputRow(
                inputText = uiState.inputText,
                micState = uiState.state,
                hasMicPermission = uiState.hasMicPermission,
                onInputTextChanged = onInputTextChanged,
                onSendTypedMessage = onSendTypedMessage,
                onMicTapped = onMicTapped
            )

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun TopStatusBar(isOnline: Boolean, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(JarvisBackground)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "JARVIS",
                color = JarvisAccent,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(if (isOnline) Color(0xFF00E676) else JarvisError)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (isOnline) "ONLINE" else "OFFLINE",
                color = JarvisTextSecondary,
                style = MaterialTheme.typography.labelSmall
            )
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = JarvisTextSecondary)
        }
    }
}

@Composable
private fun ConversationList(
    messages: List<com.originalassistant.jarvis.assistant.ChatMessage>,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(messages, key = { it.id }) { message ->
            ChatBubble(message)
        }
    }
}

@Composable
private fun StateLabel(uiState: AssistantUiState) {
    val label = when (uiState.state) {
        AssistantState.IDLE -> "Tap the mic and speak, or type below"
        AssistantState.LISTENING -> "Listening…"
        AssistantState.THINKING -> "Thinking…"
        AssistantState.SPEAKING -> "Speaking…"
        AssistantState.ERROR -> "Something went wrong"
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (uiState.state == AssistantState.THINKING) {
            CircularProgressIndicator(
                modifier = Modifier.size(14.dp),
                strokeWidth = 2.dp,
                color = JarvisAccent
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(text = label, color = JarvisTextSecondary, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun InputRow(
    inputText: String,
    micState: AssistantState,
    hasMicPermission: Boolean,
    onInputTextChanged: (String) -> Unit,
    onSendTypedMessage: () -> Unit,
    onMicTapped: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MicButton(
            state = micState,
            hasMicPermission = hasMicPermission,
            onClick = onMicTapped
        )
        Spacer(modifier = Modifier.width(10.dp))
        OutlinedTextField(
            value = inputText,
            onValueChange = onInputTextChanged,
            modifier = Modifier.weight(1f),
            placeholder = { Text("Type a command…", color = JarvisTextSecondary) },
            singleLine = true
        )
        Spacer(modifier = Modifier.width(6.dp))
        IconButton(onClick = onSendTypedMessage) {
            Icon(Icons.Default.Send, contentDescription = "Send", tint = JarvisAccent)
        }
    }
}

@Composable
private fun MicButton(
    state: AssistantState,
    hasMicPermission: Boolean,
    onClick: () -> Unit
) {
    val listening = state == AssistantState.LISTENING
    val enabled = state == AssistantState.IDLE || listening

    IconButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .size(52.dp)
            .clip(CircleShape)
            .background(if (listening) JarvisAccent else Color(0xFF1B2530))
    ) {
        Icon(
            imageVector = if (hasMicPermission) Icons.Default.Mic else Icons.Default.MicOff,
            contentDescription = "Microphone",
            tint = if (listening) JarvisBackground else JarvisAccent
        )
    }
}
