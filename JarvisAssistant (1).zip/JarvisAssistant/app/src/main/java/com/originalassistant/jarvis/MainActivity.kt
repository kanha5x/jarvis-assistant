package com.originalassistant.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.originalassistant.jarvis.assistant.AssistantViewModel
import com.originalassistant.jarvis.ui.screens.MainScreen
import com.originalassistant.jarvis.ui.screens.SettingsScreen
import com.originalassistant.jarvis.ui.theme.JarvisTheme

/**
 * App entry point.
 *
 * Responsibilities kept deliberately thin: request the runtime
 * permissions Jarvis needs (mic, and notifications on API 33+), then
 * hand everything else to Compose. All assistant logic lives in
 * [AssistantViewModel] and the screens under ui/screens.
 */
class MainActivity : ComponentActivity() {

    private val viewModel: AssistantViewModel by viewModels()

    private val micPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            viewModel.onMicPermissionResult(granted)
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op result */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Reflect whatever permission state already exists before asking
        // again (e.g. user granted it on a previous run).
        viewModel.onMicPermissionResult(hasMicPermission())

        if (!hasMicPermission()) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission()) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            JarvisTheme {
                val uiState by viewModel.uiState.collectAsState()
                val navController = rememberNavController()

                NavHost(navController = navController, startDestination = "main") {
                    composable("main") {
                        MainScreen(
                            uiState = uiState,
                            onMicTapped = viewModel::onMicButtonTapped,
                            onInputTextChanged = viewModel::onInputTextChanged,
                            onSendTypedMessage = viewModel::onSendTypedMessage,
                            onOpenSettings = { navController.navigate("settings") },
                            onDismissError = viewModel::dismissError,
                            onConfirmPendingAction = viewModel::onConfirmPendingAction,
                            onCancelPendingAction = viewModel::onCancelPendingAction
                        )
                    }
                    composable("settings") {
                        SettingsScreen(
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    private fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun hasNotificationPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
}
