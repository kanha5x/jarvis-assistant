package com.originalassistant.jarvis.assistant

import com.originalassistant.jarvis.command.ParsedCommand
import java.util.UUID

/**
 * Visual/behavioral state of the assistant core (the animated orb).
 * Drives both the orb animation and what the mic button does when tapped.
 */
enum class AssistantState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

enum class Sender { USER, ASSISTANT }

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val timestampMillis: Long = System.currentTimeMillis()
)

/**
 * A sensitive action (SEND_MESSAGE / MAKE_CALL) that is waiting for the
 * user to explicitly confirm or cancel before it runs (requirement #7/#10).
 */
data class PendingAction(
    val command: ParsedCommand,
    val confirmationPrompt: String
)

/** Whole-screen UI state consumed by MainScreen. */
data class AssistantUiState(
    val state: AssistantState = AssistantState.IDLE,
    val isOnline: Boolean = true,
    val messages: List<ChatMessage> = emptyList(),
    val partialTranscript: String = "",
    val inputText: String = "",
    val errorMessage: String? = null,
    val hasMicPermission: Boolean = false,
    val pendingAction: PendingAction? = null
)
