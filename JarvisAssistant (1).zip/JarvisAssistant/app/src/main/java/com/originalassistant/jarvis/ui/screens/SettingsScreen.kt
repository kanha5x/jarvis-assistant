package com.originalassistant.jarvis.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.originalassistant.jarvis.assistant.SettingsViewModel
import com.originalassistant.jarvis.ui.theme.JarvisAccent
import com.originalassistant.jarvis.ui.theme.JarvisBackground
import com.originalassistant.jarvis.ui.theme.JarvisTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        containerColor = JarvisBackground,
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {
            item { SectionTitle("AI Provider") }
            item { InfoRow(label = "Provider", value = state.aiProviderName) }
            item {
                Text(
                    "Configure a real provider by setting AI_BACKEND_BASE_URL in gradle.properties " +
                        "(see the setup notes) — no API key is ever stored in the app itself.",
                    color = JarvisTextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            item { SectionTitle("Voice") }
            item {
                LanguageRow(
                    current = state.language,
                    onSelect = viewModel::onLanguageSelected
                )
            }
            item {
                Text("Speech speed", color = JarvisTextSecondary, style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = state.speechRate,
                    onValueChange = viewModel::onSpeechRateChanged,
                    valueRange = 0.5f..2.0f
                )
            }
            item {
                Button(
                    onClick = viewModel::onTestAssistantTapped,
                    enabled = !state.isTestSpeaking,
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Text(if (state.isTestSpeaking) "Speaking…" else "Test Assistant")
                }
            }

            item { SectionTitle("Wake Word") }
            item {
                ToggleRow(
                    label = "Enable \"Jarvis\" wake word (foreground only)",
                    checked = state.wakeWordEnabled,
                    onCheckedChange = viewModel::onWakeWordToggled
                )
            }
            item {
                Text(
                    "Android does not allow apps to continuously record audio in the background. " +
                        "When enabled, Jarvis listens for the wake word only while this screen is open " +
                        "and in the foreground — not when the app is closed or the screen is off.",
                    color = JarvisTextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            item { SectionTitle("Auto-Listening") }
            item {
                ToggleRow(
                    label = "Automatically listen again after each reply",
                    checked = state.autoListenAfterReply,
                    onCheckedChange = viewModel::onAutoListenToggled
                )
            }

            item { SectionTitle("Memory") }
            item {
                if (state.memoryFacts.isEmpty()) {
                    Text(
                        "Nothing saved yet. Say \"remember that...\" to Jarvis to store a preference.",
                        color = JarvisTextSecondary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            items(state.memoryFacts) { fact ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(fact.fact, modifier = Modifier.weight(1f))
                    IconButton(onClick = { viewModel.onDeleteMemory(fact) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = JarvisTextSecondary)
                    }
                }
            }
            if (state.memoryFacts.isNotEmpty()) {
                item {
                    Button(
                        onClick = viewModel::onClearAllMemory,
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        Text("Clear all memory")
                    }
                }
            }

            item { SectionTitle("Privacy") }
            item {
                Text(
                    "Jarvis only listens while you tap the mic (or, if wake word is on, while this " +
                        "screen is open). Memory is stored locally on your device and is never " +
                        "collected automatically — only what you explicitly ask it to remember.",
                    color = JarvisTextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            item { SectionTitle("About") }
            item {
                Text(
                    "Jarvis — an original personal AI assistant. Not affiliated with Marvel or any " +
                        "other trademark holder.",
                    color = JarvisTextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(bottom = 24.dp)
                )
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        color = JarvisAccent,
        style = MaterialTheme.typography.titleLarge,
        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
    )
    Divider(modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = JarvisTextSecondary)
        Text(value)
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun LanguageRow(current: String, onSelect: (String) -> Unit) {
    val options = listOf("hi-IN" to "Hindi / Hinglish", "en-IN" to "English (India)", "en-US" to "English (US)")
    Column(modifier = Modifier.padding(bottom = 12.dp)) {
        options.forEach { (tag, label) ->
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(label)
                Switch(checked = current == tag, onCheckedChange = { if (it) onSelect(tag) })
            }
        }
    }
}
