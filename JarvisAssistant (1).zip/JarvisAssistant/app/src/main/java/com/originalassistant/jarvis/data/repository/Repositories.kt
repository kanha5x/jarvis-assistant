package com.originalassistant.jarvis.data.repository

import com.originalassistant.jarvis.data.db.MemoryDao
import com.originalassistant.jarvis.data.db.MemoryEntity
import com.originalassistant.jarvis.data.db.NoteDao
import com.originalassistant.jarvis.data.db.NoteEntity
import com.originalassistant.jarvis.data.db.ReminderDao
import com.originalassistant.jarvis.data.db.ReminderEntity
import kotlinx.coroutines.flow.Flow

class NoteRepository(private val dao: NoteDao) {
    suspend fun addNote(content: String): Long = dao.insert(NoteEntity(content = content))
    suspend fun getAllNotes(): List<NoteEntity> = dao.getAll()
    fun observeNotes(): Flow<List<NoteEntity>> = dao.observeAll()
    suspend fun deleteNote(note: NoteEntity) = dao.delete(note)
}

/**
 * Local-only memory store. Only ever written to via an explicit
 * "remember that ..." command from the user — see requirement #9 and
 * the privacy note in [com.originalassistant.jarvis.command.ActionExecutor].
 */
class MemoryRepository(private val dao: MemoryDao) {
    suspend fun remember(fact: String): Long = dao.insert(MemoryEntity(fact = fact))
    suspend fun getAll(): List<MemoryEntity> = dao.getAll()
    fun observeAll(): Flow<List<MemoryEntity>> = dao.observeAll()

    /** Deletes any stored facts whose text mentions [topic]. Returns how many were removed. */
    suspend fun forgetAboutTopic(topic: String): Int {
        val matches = dao.findByTopic(topic)
        matches.forEach { dao.delete(it) }
        return matches.size
    }

    suspend fun clearAll() = dao.clearAll()
}

class ReminderRepository(private val dao: ReminderDao) {
    suspend fun addReminder(message: String, triggerAtMillis: Long, recurringDaily: Boolean = false): Long =
        dao.insert(ReminderEntity(message = message, triggerAtMillis = triggerAtMillis, isRecurringDaily = recurringDaily))
    fun observeAll(): Flow<List<ReminderEntity>> = dao.observeAll()
    suspend fun delete(reminder: ReminderEntity) = dao.delete(reminder)
}
