package com.originalassistant.jarvis.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.originalassistant.jarvis.assistant.ChatMessage
import com.originalassistant.jarvis.assistant.Sender
import com.originalassistant.jarvis.ui.theme.AssistantBubble
import com.originalassistant.jarvis.ui.theme.JarvisTextPrimary
import com.originalassistant.jarvis.ui.theme.UserBubble

@Composable
fun ChatBubble(message: ChatMessage, modifier: Modifier = Modifier) {
    val isUser = message.sender == Sender.USER
    val bubbleColor = if (isUser) UserBubble else AssistantBubble

    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .background(bubbleColor, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                text = message.text,
                color = JarvisTextPrimary,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
