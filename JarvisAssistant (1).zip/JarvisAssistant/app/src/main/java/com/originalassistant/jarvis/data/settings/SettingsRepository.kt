package com.originalassistant.jarvis.data.settings

import android.content.Context

/**
 * Simple, dependency-free settings store backed by SharedPreferences.
 * Covers the toggles listed in requirement #13 (Settings screen).
 */
class SettingsRepository(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var language: String
        get() = prefs.getString(KEY_LANGUAGE, "hi-IN") ?: "hi-IN"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var speechRate: Float
        get() = prefs.getFloat(KEY_SPEECH_RATE, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_RATE, value).apply()

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean(KEY_WAKE_WORD, false)
        set(value) = prefs.edit().putBoolean(KEY_WAKE_WORD, value).apply()

    var autoListenAfterReply: Boolean
        get() = prefs.getBoolean(KEY_AUTO_LISTEN, false)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_LISTEN, value).apply()

    var aiProviderName: String
        get() = prefs.getString(KEY_AI_PROVIDER, "Local (offline demo)") ?: "Local (offline demo)"
        set(value) = prefs.edit().putString(KEY_AI_PROVIDER, value).apply()

    companion object {
        private const val PREFS_NAME = "jarvis_settings"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_WAKE_WORD = "wake_word_enabled"
        private const val KEY_AUTO_LISTEN = "auto_listen"
        private const val KEY_AI_PROVIDER = "ai_provider"
    }
}
