package com.originalassistant.jarvis.ai

import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Fully local, deterministic AI implementation.
 *
 * This exists so the whole app — mic, STT, orb states, chat UI, TTS —
 * is real and testable in Phase 1 without any API key or backend.
 * It understands a handful of Hindi/Hinglish/English phrases directly
 * and otherwise gives an honest fallback reply. In Phase 2 this class
 * is swapped out (behind the same [AIService] interface) for one that
 * calls a real language model through your backend.
 */
class MockAIService : AIService {

    override suspend fun generateResponse(history: List<AiTurn>, userMessage: String): String {
        // Small delay so the "Thinking" orb state is visible and the UX
        // feels honest about doing work, rather than snapping instantly.
        delay(400)
        val msg = userMessage.trim().lowercase(Locale.getDefault())

        return when {
            msg.containsAny("kaise ho", "kya haal", "how are you") ->
                "Main bilkul ready hoon. Aapka next command?"

            msg.containsAny("naam kya", "your name", "who are you", "tum kaun") ->
                "Main Jarvis hoon — aapka personal AI assistant."

            msg.containsAny("time kya", "what time", "samay kya") -> {
                val t = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                "Abhi time hai $t."
            }

            msg.containsAny("date kya", "aaj ki tareekh", "what's the date", "what is the date") -> {
                val d = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())
                "Aaj ki tareekh hai $d."
            }

            msg.containsAny("joke suna", "tell me a joke", "funny joke") ->
                "Ek AI doosre AI se bola: 'tumhe bhi neend nahi aati?' Doosra bola: 'nahi yaar, main to bas idle state mein rehta hoon.'"

            msg.containsAny("thank you", "shukriya", "dhanyavaad") ->
                "Koi baat nahi. Main yahin hoon."

            msg.containsAny("hello", "hi jarvis", "namaste", "hey jarvis") ->
                "Namaste. Main sun raha hoon."

            else ->
                "Abhi mera pura AI brain connect nahi hai, lekin main aapki baat sun raha hoon: \"$userMessage\". " +
                    "Phase 2 mein main isse zyada samajhdaari se jawab doonga."
        }
    }

    override suspend fun classifyIntent(userMessage: String): Intent {
        // Real intent classification (OPEN_APP, SET_TIMER, etc.) is built in
        // Phase 3's CommandParser. Phase 1 only needs conversational replies,
        // so every utterance is treated as general chat for now.
        return Intent(action = "GENERAL_AI_CHAT")
    }

    override suspend fun extractCommandParameters(
        action: String,
        userMessage: String
    ): Map<String, String> = emptyMap()

    private fun String.containsAny(vararg needles: String): Boolean =
        needles.any { this.contains(it) }
}
