package com.originalassistant.jarvis.command

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import com.originalassistant.jarvis.data.repository.MemoryRepository
import com.originalassistant.jarvis.data.repository.NoteRepository
import com.originalassistant.jarvis.data.repository.ReminderRepository
import com.originalassistant.jarvis.reminder.ReminderManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Executes a [ParsedCommand] and returns the natural-language reply Jarvis
 * should speak back. Every action here uses official Android APIs/intents —
 * nothing bypasses permissions or platform restrictions (requirement #6/#15).
 *
 * [SEND_MESSAGE] and [CommandAction.MAKE_CALL] are intentionally NOT executed
 * directly by this class. The ViewModel intercepts those two actions first
 * to show a confirmation dialog (requirement #7/#10); this executor only
 * ever runs them after the user has explicitly confirmed.
 */
class ActionExecutor(
    private val context: Context,
    private val noteRepository: NoteRepository,
    private val memoryRepository: MemoryRepository,
    private val reminderRepository: ReminderRepository,
    private val reminderManager: ReminderManager
) {

    private val appPackages = mapOf(
        "whatsapp" to listOf("com.whatsapp"),
        "instagram" to listOf("com.instagram.android"),
        "youtube" to listOf("com.google.android.youtube"),
        "chrome" to listOf("com.android.chrome"),
        "gmail" to listOf("com.google.android.gm"),
        "gallery" to listOf("com.google.android.apps.photos"),
        "photos" to listOf("com.google.android.apps.photos"),
        "maps" to listOf("com.google.android.apps.maps"),
        "facebook" to listOf("com.facebook.katana"),
        "spotify" to listOf("com.spotify.music"),
        "calendar" to listOf("com.google.android.calendar"),
        "calculator" to listOf("com.google.android.calculator", "com.android.calculator2"),
        "play store" to listOf("com.android.vending"),
        "playstore" to listOf("com.android.vending")
    )

    suspend fun execute(command: ParsedCommand): ActionResult = when (command.action) {
        CommandAction.OPEN_APP -> openApp(command.parameters["appName"].orEmpty())
        CommandAction.OPEN_SETTINGS -> openSettings()
        CommandAction.SEARCH_WEB -> searchWeb(command.parameters["query"].orEmpty())
        CommandAction.SEARCH_YOUTUBE -> searchYoutube(command.parameters["query"].orEmpty())
        CommandAction.GET_BATTERY -> getBattery()
        CommandAction.GET_TIME -> getTime()
        CommandAction.GET_DATE -> getDate()
        CommandAction.CALCULATOR -> calculate(command.parameters["expression"].orEmpty())
        CommandAction.SET_TIMER -> setTimer(command.parameters)
        CommandAction.SET_ALARM -> setAlarm(command.parameters)
        CommandAction.CREATE_REMINDER -> createReminder(command.parameters)
        CommandAction.CREATE_NOTE -> createNote(command.parameters["content"].orEmpty())
        CommandAction.READ_NOTE -> readNotes()
        CommandAction.REMEMBER_FACT -> rememberFact(command.parameters["fact"].orEmpty())
        CommandAction.FORGET_FACT -> forgetFact(command.parameters["topic"].orEmpty())
        CommandAction.LIST_MEMORY -> listMemory()
        CommandAction.GET_WEATHER -> ActionResult(
            "Weather ke liye abhi mujhe internet-based weather service se connect karna hoga — ye Phase 2 mein add hoga.",
            success = false
        )
        // SEND_MESSAGE / MAKE_CALL are executed via executeConfirmed() after user confirmation.
        else -> ActionResult("Maaf kijiye, ye command abhi supported nahi hai.", success = false)
    }

    /** Called only after the user has tapped "confirm" on a sensitive action. */
    fun executeConfirmed(command: ParsedCommand): ActionResult = when (command.action) {
        CommandAction.SEND_MESSAGE -> sendMessage(command.parameters)
        CommandAction.MAKE_CALL -> makeCall(command.parameters)
        else -> ActionResult("Ye action confirmation ke through execute nahi hota.", success = false)
    }

    // ---- Apps -------------------------------------------------------

    private fun openApp(appName: String): ActionResult {
        if (appName == "settings") return openSettings()
        if (appName == "phone" || appName == "dialer") {
            context.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return ActionResult("Phone dialer khol raha hoon.")
        }
        if (appName == "camera") {
            val intent = Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                ActionResult("Camera khol raha hoon.")
            } else {
                ActionResult("Mujhe camera app nahi mil paya.", success = false)
            }
        }

        val candidatePackages = appPackages[appName] ?: return ActionResult(
            "Maaf kijiye, mujhe \"$appName\" app nahi pata. Aap app ka naam clearly bol sakte hain?",
            success = false
        )

        val pm = context.packageManager
        for (pkg in candidatePackages) {
            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return ActionResult("Bilkul. ${appName.replaceFirstChar { it.uppercase() }} khol raha hoon.")
            }
        }

        // App isn't installed — offer the Play Store listing instead of failing silently.
        return try {
            val storeIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("market://details?id=${candidatePackages.first()}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(storeIntent)
            ActionResult("${appName.replaceFirstChar { it.uppercase() }} install nahi hai. Play Store khol raha hoon.")
        } catch (e: PackageManager.NameNotFoundException) {
            ActionResult("$appName install nahi hai aur Play Store bhi nahi mila.", success = false)
        }
    }

    private fun openSettings(): ActionResult {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActionResult("Settings khol raha hoon.")
    }

    // ---- Search -------------------------------------------------------

    private fun searchWeb(query: String): ActionResult {
        if (query.isBlank()) return ActionResult("Aap kya search karna chahte hain?", success = false)
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            ActionResult("\"$query\" search kar raha hoon.")
        } catch (e: Exception) {
            // Fallback: open a browser search URL directly.
            val fallback = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(fallback)
            ActionResult("\"$query\" search kar raha hoon.")
        }
    }

    private fun searchYoutube(query: String): ActionResult {
        if (query.isBlank()) return ActionResult("YouTube pe kya search karna hai?", success = false)
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return ActionResult("YouTube pe \"$query\" search kar raha hoon.")
    }

    // ---- Device info -------------------------------------------------------

    private fun getBattery(): ActionResult {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return ActionResult("Battery abhi $level percent hai.")
    }

    private fun getTime(): ActionResult {
        val time = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        return ActionResult("Abhi time hai $time.")
    }

    private fun getDate(): ActionResult {
        val date = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(Date())
        return ActionResult("Aaj ki tareekh hai $date.")
    }

    // ---- Calculator -------------------------------------------------------

    private fun calculate(expression: String): ActionResult {
        if (expression.isBlank()) return ActionResult("Kya calculate karna hai?", success = false)
        val result = SimpleExpressionEvaluator.evaluate(expression)
        return if (result != null) {
            ActionResult("$expression barabar hai $result.")
        } else {
            ActionResult("Maaf kijiye, ye expression samajh nahi aaya.", success = false)
        }
    }

    // ---- Timer & alarm (via the system Clock app — the officially sanctioned mechanism) ----

    private fun setTimer(params: Map<String, String>): ActionResult {
        val amount = params["amount"]?.toIntOrNull() ?: return ActionResult("Kitne der ka timer laga doon?", success = false)
        val unit = params["unit"] ?: "minute"
        val seconds = when (unit) {
            "second" -> amount
            "hour" -> amount * 3600
            else -> amount * 60
        }
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            ActionResult("$amount $unit ka timer laga diya hai.")
        } else {
            ActionResult("Is device par koi Clock app nahi mila timer set karne ke liye.", success = false)
        }
    }

    private fun setAlarm(params: Map<String, String>): ActionResult {
        val hour24 = resolveHour24(params) ?: return ActionResult("Kis time ka alarm laga doon?", success = false)
        val minute = params["minute"]?.toIntOrNull() ?: 0

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour24)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            val label = String.format(Locale.getDefault(), "%02d:%02d", hour24, minute)
            ActionResult("$label ka alarm laga diya hai.")
        } else {
            ActionResult("Is device par koi Clock app nahi mila alarm set karne ke liye.", success = false)
        }
    }

    private suspend fun createReminder(params: Map<String, String>): ActionResult {
        val message = params["message"]?.takeUnless { it.isBlank() } ?: "Reminder"
        val triggerAtMillis = resolveReminderTriggerMillis(params)
            ?: return ActionResult("Reminder kab ka lagau, ye clear nahi hua. Time ya duration bataiye.", success = false)

        val id = reminderRepository.addReminder(message, triggerAtMillis)
        val wasExact = reminderManager.scheduleReminder(id, message, triggerAtMillis)

        val whenText = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(triggerAtMillis))
        return if (wasExact) {
            ActionResult("Theek hai, \"$message\" ke liye $whenText ko reminder laga diya hai.")
        } else {
            ActionResult(
                "\"$message\" ke liye $whenText ko reminder laga diya hai, lekin exact-alarm permission na hone ki wajah se ye kuch minute late ho sakta hai. Settings mein exact alarms allow kar sakte hain."
            )
        }
    }

    private fun resolveReminderTriggerMillis(params: Map<String, String>): Long? {
        val calendar = Calendar.getInstance()
        val amount = params["amount"]?.toIntOrNull()
        val unit = params["unit"]

        if (amount != null && unit != null) {
            when (unit) {
                "second" -> calendar.add(Calendar.SECOND, amount)
                "hour" -> calendar.add(Calendar.HOUR_OF_DAY, amount)
                else -> calendar.add(Calendar.MINUTE, amount)
            }
            return calendar.timeInMillis
        }

        val hour24 = resolveHour24(params)
        if (hour24 != null) {
            val minute = params["minute"]?.toIntOrNull() ?: 0
            calendar.set(Calendar.HOUR_OF_DAY, hour24)
            calendar.set(Calendar.MINUTE, minute)
            calendar.set(Calendar.SECOND, 0)
            if (calendar.timeInMillis <= System.currentTimeMillis()) {
                calendar.add(Calendar.DAY_OF_YEAR, 1) // time already passed today -> tomorrow
            }
            return calendar.timeInMillis
        }

        return null
    }

    private fun resolveHour24(params: Map<String, String>): Int? {
        val hour = params["hour"]?.toIntOrNull() ?: return null
        val meridiem = params["meridiem"]?.lowercase(Locale.getDefault()).orEmpty()
        return when {
            meridiem == "pm" && hour != 12 -> hour + 12
            meridiem == "am" && hour == 12 -> 0
            else -> hour
        }
    }

    // ---- Notes -------------------------------------------------------

    private suspend fun createNote(content: String): ActionResult {
        if (content.isBlank()) return ActionResult("Note mein kya likhu?", success = false)
        noteRepository.addNote(content)
        return ActionResult("Note save kar diya hai.")
    }

    private suspend fun readNotes(): ActionResult {
        val notes = noteRepository.getAllNotes()
        if (notes.isEmpty()) return ActionResult("Aapke paas abhi koi note saved nahi hai.")
        val latest = notes.take(3).joinToString(". ") { it.content }
        return ActionResult("Aapke recent notes: $latest")
    }

    // ---- Memory -------------------------------------------------------

    private suspend fun rememberFact(fact: String): ActionResult {
        if (fact.isBlank()) return ActionResult("Kya yaad rakhna hai, bata dijiye.", success = false)
        memoryRepository.remember(fact)
        return ActionResult("Theek hai, main ye yaad rakhunga: \"$fact\".")
    }

    private suspend fun forgetFact(topic: String): ActionResult {
        if (topic.isBlank()) return ActionResult("Kis baare mein bhoolna hai?", success = false)
        val removed = memoryRepository.forgetAboutTopic(topic)
        return if (removed > 0) {
            ActionResult("$topic ke baare mein jo bhi yaad tha, bhula diya hai.")
        } else {
            ActionResult("Mujhe $topic ke baare mein kuch yaad nahi tha.")
        }
    }

    private suspend fun listMemory(): ActionResult {
        val facts = memoryRepository.getAll()
        if (facts.isEmpty()) return ActionResult("Abhi mujhe aapke baare mein kuch bhi yaad nahi hai.")
        val summary = facts.take(5).joinToString(". ") { it.fact }
        return ActionResult("Mujhe ye yaad hai: $summary")
    }

    // ---- Confirmed sensitive actions (requirement #7) -------------------------------------------------------

    private fun sendMessage(params: Map<String, String>): ActionResult {
        val body = params["body"].orEmpty()
        // Opens the user's default SMS app pre-filled with the message.
        // The user still has to tap Send themselves inside that app —
        // Jarvis never transmits a message without that final human action.
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:")
            putExtra("sms_body", body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            ActionResult("Messages app khol diya hai, message bhejne ke liye Send dabaiye.")
        } else {
            ActionResult("Is device par koi messaging app nahi mila.", success = false)
        }
    }

    private fun makeCall(params: Map<String, String>): ActionResult {
        // ACTION_DIAL opens the dialer with the number pre-filled but does
        // NOT place the call automatically — the user must press the call
        // button themselves. This avoids requiring the CALL_PHONE dangerous
        // permission at all while still fulfilling requirement #7's need
        // for a confirmed, user-driven call flow.
        val contact = params["contact"].orEmpty()
        val intent = Intent(Intent.ACTION_DIAL).apply {
            if (contact.isNotBlank() && contact.all { it.isDigit() || it in "+- ()" }) {
                data = Uri.parse("tel:$contact")
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return ActionResult("Dialer khol diya hai, call connect karne ke liye button dabaiye.")
    }
}

/** Minimal, dependency-free arithmetic evaluator for the CALCULATOR command. */
private object SimpleExpressionEvaluator {
    fun evaluate(expression: String): Double? = try {
        val tokens = tokenize(expression)
        evaluateTokens(tokens)
    } catch (e: Exception) {
        null
    }

    private fun tokenize(expr: String): List<String> {
        val regex = Regex("""(\d+\.?\d*)|([+\-x*/])""")
        return regex.findAll(expr).map { it.value }.toList()
    }

    private fun evaluateTokens(tokens: List<String>): Double? {
        if (tokens.isEmpty()) return null
        // First pass: multiplication/division (left to right)
        val stack = mutableListOf<String>()
        var i = 0
        while (i < tokens.size) {
            val token = tokens[i]
            if (token == "x" || token == "*" || token == "/") {
                val left = stack.removeAt(stack.size - 1).toDouble()
                val right = tokens[i + 1].toDouble()
                val result = if (token == "/") left / right else left * right
                stack.add(result.toString())
                i += 2
            } else {
                stack.add(token)
                i += 1
            }
        }
        // Second pass: addition/subtraction (left to right)
        var total = stack[0].toDouble()
        var j = 1
        while (j < stack.size) {
            val op = stack[j]
            val value = stack[j + 1].toDouble()
            total = if (op == "+") total + value else total - value
            j += 2
        }
        return total
    }
}
