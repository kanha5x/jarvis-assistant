package com.originalassistant.jarvis.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import com.originalassistant.jarvis.assistant.PendingAction

/**
 * Shown whenever a sensitive action (sending a message, placing a call)
 * is waiting for explicit user approval — requirement #7/#10. Nothing is
 * sent or dialed until the user taps "Confirm" here.
 */
@Composable
fun ConfirmationDialog(
    pendingAction: PendingAction,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Confirm action") },
        text = { Text(pendingAction.confirmationPrompt) },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text("Confirm") }
        },
        dismissButton = {
            TextButton(onClick = onCancel) { Text("Cancel") }
        }
    )
}
