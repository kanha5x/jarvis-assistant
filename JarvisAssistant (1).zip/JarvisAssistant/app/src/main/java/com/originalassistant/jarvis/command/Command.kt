package com.originalassistant.jarvis.command

/**
 * The full command registry (requirement #5). Adding a new capability to
 * Jarvis means: add a case here, teach [com.originalassistant.jarvis.command.CommandParser]
 * to recognize it, and teach [com.originalassistant.jarvis.command.ActionExecutor] to run it.
 * Nothing else in the app needs to change.
 */
enum class CommandAction {
    OPEN_APP,
    SEARCH_WEB,
    SEARCH_YOUTUBE,
    SET_ALARM,
    SET_TIMER,
    CREATE_REMINDER,
    GET_BATTERY,
    GET_TIME,
    GET_DATE,
    GET_WEATHER,
    CALCULATOR,
    CREATE_NOTE,
    READ_NOTE,
    SEND_MESSAGE,
    MAKE_CALL,
    OPEN_SETTINGS,
    REMEMBER_FACT,
    FORGET_FACT,
    LIST_MEMORY,
    GENERAL_AI_CHAT,
    UNKNOWN
}

/** Whether running a command needs an explicit user tap before it happens (requirement #7/#10). */
fun CommandAction.requiresConfirmation(): Boolean =
    this == CommandAction.SEND_MESSAGE || this == CommandAction.MAKE_CALL

/** The structured result of parsing one utterance. */
data class ParsedCommand(
    val action: CommandAction,
    val parameters: Map<String, String> = emptyMap(),
    val rawText: String
)

/** The result of actually running a [ParsedCommand]. */
data class ActionResult(
    val spokenReply: String,
    val success: Boolean = true
)
