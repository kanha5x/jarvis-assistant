package com.originalassistant.jarvis.ui.theme

import androidx.compose.ui.graphics.Color

// Original dark/futuristic palette — cyan/teal accent instead of
// Marvel's red/gold to keep the visual identity distinct.
val JarvisBackground = Color(0xFF05070A)
val JarvisSurface = Color(0xFF0D1117)
val JarvisSurfaceVariant = Color(0xFF161B22)

val JarvisAccent = Color(0xFF00E5FF)
val JarvisAccentDim = Color(0xFF0097A7)
val JarvisAccentSoft = Color(0xFF3A5A63)

val JarvisError = Color(0xFFFF5252)
val JarvisWarning = Color(0xFFFFB300)

val JarvisTextPrimary = Color(0xFFE6F1F5)
val JarvisTextSecondary = Color(0xFF8A9BA8)

val UserBubble = Color(0xFF1B2530)
val AssistantBubble = Color(0xFF0D2B30)
