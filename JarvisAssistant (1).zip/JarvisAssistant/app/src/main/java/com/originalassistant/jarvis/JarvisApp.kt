package com.originalassistant.jarvis

import android.app.Application

/**
 * Application entry point.
 *
 * Phase 1: nothing to initialize yet beyond the default Application.
 * Phase 5 will initialize the Room database and a simple manual DI
 * container here (ServiceLocator pattern) so ViewModels can obtain
 * repositories without a heavyweight DI framework.
 */
class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
