package com.originalassistant.jarvis.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Insert
    suspend fun insert(note: NoteEntity): Long

    @Query("SELECT * FROM notes ORDER BY createdAtMillis DESC")
    fun observeAll(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes ORDER BY createdAtMillis DESC")
    suspend fun getAll(): List<NoteEntity>

    @Delete
    suspend fun delete(note: NoteEntity)
}

@Dao
interface MemoryDao {
    @Insert
    suspend fun insert(memory: MemoryEntity): Long

    @Query("SELECT * FROM memory ORDER BY createdAtMillis DESC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memory ORDER BY createdAtMillis DESC")
    suspend fun getAll(): List<MemoryEntity>

    @Query("SELECT * FROM memory WHERE fact LIKE '%' || :topic || '%'")
    suspend fun findByTopic(topic: String): List<MemoryEntity>

    @Delete
    suspend fun delete(memory: MemoryEntity)

    @Query("DELETE FROM memory")
    suspend fun clearAll()
}

@Dao
interface ReminderDao {
    @Insert
    suspend fun insert(reminder: ReminderEntity): Long

    @Query("SELECT * FROM reminders ORDER BY triggerAtMillis ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Delete
    suspend fun delete(reminder: ReminderEntity)
}
