package com.originalassistant.jarvis.ai

/** A single turn in the conversation, used as context for the AI provider. */
data class AiTurn(val role: String, val content: String) // role: "user" | "assistant"

/** Structured intent classification result — feeds the CommandParser in Phase 3. */
data class Intent(
    val action: String,          // e.g. "OPEN_APP", "GENERAL_AI_CHAT"
    val parameters: Map<String, String> = emptyMap(),
    val confidence: Float = 1.0f
)

/**
 * Provider-agnostic AI abstraction. Nothing in the UI or ViewModel layer
 * talks to a specific AI vendor directly — everything goes through this
 * interface, so the backend can be swapped (OpenAI/Anthropic/local model/
 * your own server) without touching app code.
 *
 * Phase 1 ships [MockAIService], a fully local, deterministic
 * implementation so the app is testable end-to-end with zero API keys.
 * Phase 2 replaces it with an implementation that calls a backend you
 * control (see the accompanying setup notes) — the Android client should
 * never hold a raw AI provider secret key.
 */
interface AIService {
    /** Free-form conversational reply, given the running history. */
    suspend fun generateResponse(history: List<AiTurn>, userMessage: String): String

    /** Classifies a raw utterance into a structured [Intent]. */
    suspend fun classifyIntent(userMessage: String): Intent

    /** Pulls out any extra parameters an already-known action still needs. */
    suspend fun extractCommandParameters(
        action: String,
        userMessage: String
    ): Map<String, String>
}
