package com.originalassistant.jarvis.assistant

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.originalassistant.jarvis.ai.AIService
import com.originalassistant.jarvis.ai.AiTurn
import com.originalassistant.jarvis.ai.MockAIService
import com.originalassistant.jarvis.command.ActionExecutor
import com.originalassistant.jarvis.command.CommandAction
import com.originalassistant.jarvis.command.CommandParser
import com.originalassistant.jarvis.command.ParsedCommand
import com.originalassistant.jarvis.command.requiresConfirmation
import com.originalassistant.jarvis.data.db.AppDatabase
import com.originalassistant.jarvis.data.repository.MemoryRepository
import com.originalassistant.jarvis.data.repository.NoteRepository
import com.originalassistant.jarvis.data.repository.ReminderRepository
import com.originalassistant.jarvis.data.settings.SettingsRepository
import com.originalassistant.jarvis.reminder.ReminderManager
import com.originalassistant.jarvis.speech.SpeechRecognizerService
import com.originalassistant.jarvis.speech.TextToSpeechService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Owns the assistant's conversational state and coordinates the full
 * pipeline described in requirement #3:
 *
 *   voice/typed input -> CommandParser -> (confirmation if sensitive) ->
 *   ActionExecutor OR AIService -> text-to-speech -> UI update
 *
 * [CommandParser] runs first and is fully offline/deterministic — it
 * handles the fixed vocabulary of supported commands (open app, search,
 * timers, alarms, reminders, notes, memory, calls/messages). Anything it
 * doesn't recognize (CommandAction.GENERAL_AI_CHAT) falls through to
 * [aiService] for a free-form conversational reply.
 */
class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val speechRecognizer = SpeechRecognizerService(application)
    private val textToSpeech = TextToSpeechService(application)
    private val aiService: AIService = MockAIService()
    private val settingsRepository = SettingsRepository(application)

    private val database = AppDatabase.getInstance(application)
    private val noteRepository = NoteRepository(database.noteDao())
    private val memoryRepository = MemoryRepository(database.memoryDao())
    private val reminderRepository = ReminderRepository(database.reminderDao())
    private val reminderManager = ReminderManager(application)

    private val actionExecutor = ActionExecutor(
        context = application,
        noteRepository = noteRepository,
        memoryRepository = memoryRepository,
        reminderRepository = reminderRepository,
        reminderManager = reminderManager
    )

    private val _uiState = MutableStateFlow(AssistantUiState())
    val uiState: StateFlow<AssistantUiState> = _uiState

    init {
        textToSpeech.language = Locale.forLanguageTag(settingsRepository.language)
        textToSpeech.speechRate = settingsRepository.speechRate
    }

    fun onMicPermissionResult(granted: Boolean) {
        _uiState.update { it.copy(hasMicPermission = granted) }
    }

    fun onMicButtonTapped() {
        val current = _uiState.value
        if (!current.hasMicPermission) {
            _uiState.update { it.copy(errorMessage = "Microphone permission is required to listen.") }
            return
        }

        if (current.state == AssistantState.LISTENING) {
            speechRecognizer.stopListening()
            _uiState.update { it.copy(state = AssistantState.IDLE, partialTranscript = "") }
            return
        }

        if (current.state != AssistantState.IDLE) return // ignore taps while thinking/speaking

        _uiState.update { it.copy(state = AssistantState.LISTENING, partialTranscript = "", errorMessage = null) }

        speechRecognizer.startListening(
            languageTag = settingsRepository.language,
            onPartialResult = { partial ->
                _uiState.update { it.copy(partialTranscript = partial) }
            },
            onFinalResult = { finalText ->
                _uiState.update { it.copy(partialTranscript = "") }
                submitUserMessage(finalText)
            },
            onError = { errorText ->
                _uiState.update {
                    it.copy(
                        state = AssistantState.ERROR,
                        partialTranscript = "",
                        errorMessage = errorText
                    )
                }
                // Return to idle shortly after showing the error, so the
                // orb doesn't get permanently stuck in an error state.
                viewModelScope.launch {
                    kotlinx.coroutines.delay(1600)
                    _uiState.update { s -> s.copy(state = AssistantState.IDLE) }
                }
            }
        )
    }

    fun onInputTextChanged(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun onSendTypedMessage() {
        val text = _uiState.value.inputText.trim()
        if (text.isEmpty()) return
        _uiState.update { it.copy(inputText = "") }
        submitUserMessage(text)
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    /** User tapped "Confirm" on a pending sensitive action (SEND_MESSAGE / MAKE_CALL). */
    fun onConfirmPendingAction() {
        val pending = _uiState.value.pendingAction ?: return
        _uiState.update { it.copy(pendingAction = null, state = AssistantState.THINKING) }

        viewModelScope.launch {
            val result = actionExecutor.executeConfirmed(pending.command)
            respondAndSpeak(result.spokenReply)
        }
    }

    /** User tapped "Cancel" on a pending sensitive action. */
    fun onCancelPendingAction() {
        _uiState.update { it.copy(pendingAction = null) }
        respondAndSpeak("Theek hai, cancel kar diya.")
    }

    private fun submitUserMessage(text: String) {
        val userMessage = ChatMessage(sender = Sender.USER, text = text)
        _uiState.update {
            it.copy(
                messages = it.messages + userMessage,
                state = AssistantState.THINKING
            )
        }

        val command = CommandParser.parse(text)

        if (command.action.requiresConfirmation()) {
            handleConfirmationRequired(command)
            return
        }

        if (command.action == CommandAction.GENERAL_AI_CHAT) {
            handleGeneralChat(text)
        } else {
            handleDirectCommand(command)
        }
    }

    private fun handleConfirmationRequired(command: ParsedCommand) {
        val prompt = when (command.action) {
            CommandAction.SEND_MESSAGE -> {
                val contact = command.parameters["contact"] ?: "is contact"
                val body = command.parameters["body"] ?: command.rawText
                "$contact ko ye message bhejna hai: \"$body\". Send kar doon?"
            }
            CommandAction.MAKE_CALL -> {
                val contact = command.parameters["contact"]?.takeUnless { it.isBlank() }
                if (contact != null) "$contact ko call karna hai. Confirm karein?" else "Call karna hai. Confirm karein?"
            }
            else -> "Ye action perform karu?"
        }

        _uiState.update {
            it.copy(
                state = AssistantState.IDLE,
                pendingAction = PendingAction(command, prompt)
            )
        }
        respondAndSpeak(prompt, appendAsMessage = true)
    }

    private fun handleDirectCommand(command: ParsedCommand) {
        viewModelScope.launch {
            val result = try {
                actionExecutor.execute(command)
            } catch (t: Throwable) {
                com.originalassistant.jarvis.command.ActionResult(
                    "Maaf kijiye, is command ko execute karte waqt error aaya.",
                    success = false
                )
            }
            respondAndSpeak(result.spokenReply)
        }
    }

    private fun handleGeneralChat(text: String) {
        viewModelScope.launch {
            val history = _uiState.value.messages.map {
                AiTurn(role = if (it.sender == Sender.USER) "user" else "assistant", content = it.text)
            }

            val replyText = try {
                aiService.generateResponse(history, text)
            } catch (t: Throwable) {
                "Maaf kijiye, abhi AI response generate karne mein dikkat aa rahi hai."
            }

            respondAndSpeak(replyText)
        }
    }

    /** Appends the assistant's reply to the chat, speaks it, and updates orb state. */
    private fun respondAndSpeak(replyText: String, appendAsMessage: Boolean = true) {
        if (appendAsMessage) {
            val assistantMessage = ChatMessage(sender = Sender.ASSISTANT, text = replyText)
            _uiState.update {
                it.copy(messages = it.messages + assistantMessage, state = AssistantState.SPEAKING)
            }
        } else {
            _uiState.update { it.copy(state = AssistantState.SPEAKING) }
        }

        textToSpeech.speak(
            text = replyText,
            onDone = { _uiState.update { s -> s.copy(state = AssistantState.IDLE) } },
            onError = { _uiState.update { s -> s.copy(state = AssistantState.IDLE) } }
        )
    }

    override fun onCleared() {
        super.onCleared()
        speechRecognizer.stopListening()
        textToSpeech.shutdown()
    }
}
