package com.originalassistant.jarvis.assistant

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.originalassistant.jarvis.data.db.AppDatabase
import com.originalassistant.jarvis.data.db.MemoryEntity
import com.originalassistant.jarvis.data.repository.MemoryRepository
import com.originalassistant.jarvis.data.settings.SettingsRepository
import com.originalassistant.jarvis.speech.TextToSpeechService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

data class SettingsUiState(
    val language: String = "hi-IN",
    val speechRate: Float = 1.0f,
    val wakeWordEnabled: Boolean = false,
    val autoListenAfterReply: Boolean = false,
    val aiProviderName: String = "Local (offline demo)",
    val memoryFacts: List<MemoryEntity> = emptyList(),
    val isTestSpeaking: Boolean = false
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = SettingsRepository(application)
    private val memoryRepository = MemoryRepository(AppDatabase.getInstance(application).memoryDao())
    private val testTts = TextToSpeechService(application)

    private val _uiState = MutableStateFlow(
        SettingsUiState(
            language = settingsRepository.language,
            speechRate = settingsRepository.speechRate,
            wakeWordEnabled = settingsRepository.wakeWordEnabled,
            autoListenAfterReply = settingsRepository.autoListenAfterReply,
            aiProviderName = settingsRepository.aiProviderName
        )
    )
    val uiState: StateFlow<SettingsUiState> = _uiState

    init {
        loadMemory()
    }

    fun onLanguageSelected(languageTag: String) {
        settingsRepository.language = languageTag
        testTts.language = Locale.forLanguageTag(languageTag)
        _uiState.update { it.copy(language = languageTag) }
    }

    fun onSpeechRateChanged(rate: Float) {
        settingsRepository.speechRate = rate
        testTts.speechRate = rate
        _uiState.update { it.copy(speechRate = rate) }
    }

    fun onWakeWordToggled(enabled: Boolean) {
        settingsRepository.wakeWordEnabled = enabled
        _uiState.update { it.copy(wakeWordEnabled = enabled) }
    }

    fun onAutoListenToggled(enabled: Boolean) {
        settingsRepository.autoListenAfterReply = enabled
        _uiState.update { it.copy(autoListenAfterReply = enabled) }
    }

    fun onTestAssistantTapped() {
        _uiState.update { it.copy(isTestSpeaking = true) }
        testTts.speak(
            text = "Namaste. Main Jarvis hoon aur main theek se kaam kar raha hoon.",
            onDone = { _uiState.update { it.copy(isTestSpeaking = false) } },
            onError = { _uiState.update { it.copy(isTestSpeaking = false) } }
        )
    }

    fun onClearAllMemory() {
        viewModelScope.launch {
            memoryRepository.clearAll()
            loadMemory()
        }
    }

    fun onDeleteMemory(memory: MemoryEntity) {
        viewModelScope.launch {
            memoryRepository.forgetAboutTopic(memory.fact)
            loadMemory()
        }
    }

    private fun loadMemory() {
        viewModelScope.launch {
            val facts = memoryRepository.getAll()
            _uiState.update { it.copy(memoryFacts = facts) }
        }
    }

    override fun onCleared() {
        super.onCleared()
        testTts.shutdown()
    }
}
