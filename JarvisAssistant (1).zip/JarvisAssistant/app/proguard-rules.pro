# Add project specific ProGuard rules here.
-keep class com.originalassistant.jarvis.data.db.** { *; }
