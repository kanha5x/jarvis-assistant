# Jarvis — Personal AI Voice Assistant (Android)

Ye ek real Android Studio project hai. Neeche diye steps follow karke
apne phone mein install kar sakte hain.

## Kya-kya chahiye (Requirements)

1. Ek **Windows / Mac / Linux computer** — app phone se seedha nahi banti.
2. **Android Studio** (free) — download: https://developer.android.com/studio
3. Internet connection (pehli baar Gradle sync hone ke liye)
4. Android phone + USB cable

## Install / Build Steps

1. Is zip file ko computer mein kahin bhi **extract** kar lijiye
   (right-click → Extract Here, ya WinRAR/7-Zip se).
2. **Android Studio open kijiye.**
3. "Open" (ya "Open an Existing Project") par click kijiye.
4. Extract ki hui `JarvisAssistant` folder select kijiye aur Open dabaiye.
5. Android Studio niche "Gradle sync" karega — pehli baar mein 5-10 minute
   lag sakte hain (internet chahiye is step ke liye). Bas wait kijiye,
   kuch mat dabaiye jab tak neeche progress bar khatam na ho jaye.
6. Apne **Android phone** mein:
   - Settings → About Phone → "Build Number" ko 7 baar tap kijiye
     (isse "Developer Options" unlock ho jayega).
   - Settings → Developer Options mein jaake **USB Debugging** ON kijiye.
7. Phone ko USB cable se computer se connect kijiye. Phone par ek popup
   aayega "Allow USB debugging?" — Allow dabaiye.
8. Android Studio ke top mein, phone ka naam dikhna chahiye (device
   dropdown mein). Agar nahi dikh raha, USB cable check kijiye ya
   "File Transfer / MTP mode" phone mein select kijiye.
9. Upar green **▶ Run** button (ya Shift+F10) dabaiye.
10. Android Studio khud app ko build karke seedha aapke phone mein
    install kar dega, aur khud khul bhi jayegi.
11. Pehli baar app khulne par ye **microphone permission** maangegi —
    "Allow" kijiye, warna aap bol nahi paayenge.

Bas — app chal jayegi.

## Abhi app kya kar sakti hai (current status)

Ye "PHASE 1 + kuch commands" hai — poori app nahi (poori app bahut
saare features ki hai, wo phase-by-phase ban rahi hai jaisa maine
pehle bataya tha):

- Bol kar ya type karke baat kar sakte hain (Hindi/Hinglish/English)
- Apps khol sakte hain: WhatsApp, Instagram, YouTube, Chrome, Gmail,
  Maps, Settings, Camera, Phone/Dialer, waghera
- Web / YouTube par search karwa sakte hain
- Battery, time, date pooch sakte hain
- Calculator ("5 plus 3 kitna hota hai")
- Timer aur Alarm laga sakte hain
- Reminders set kar sakte hain
- Notes bana/padh sakte hain
- "Remember that..." bol kar cheez yaad rakhwa sakte hain
- Message bhejne/call karne se pehle confirmation maangegi (safe hai)
- Settings screen mein language, speech speed, memory manage kar sakte hain

**Abhi AI brain ek simple offline demo hai** (`MockAIService.kt`) —
real AI (jaise ek proper chatbot) connect karna agla step hai. Usse
connect karne ke liye ek API key/backend chahiye hoga, jo maine kahin
bhi code mein hardcode nahi kiya — `gradle.properties` file mein
`AI_BACKEND_BASE_URL` daalna hoga jab wo step aayega.

## Agar koi error aaye

- "Gradle sync failed" → internet connection check kijiye, phir
  File → Sync Project with Gradle Files dobara try kijiye.
- Phone dikh nahi raha → USB debugging phone mein dobara ON/OFF
  kar ke check kijiye, cable badal ke dekhiye (kuch cable sirf
  charging ke liye hote hain, data transfer ke liye nahi).
- App crash ho jaye → Android Studio ke "Logcat" tab mein red text
  dikhega, wo error message share kar dijiye, main fix kar dunga.

Koi bhi step samajh na aaye to bata dijiye, main aur simple kar dunga.
